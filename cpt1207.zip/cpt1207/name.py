import os
os.rename("sample.txt","pavan.txt")
print("Sucessfully renamed......")