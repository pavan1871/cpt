file=open("sample_binary.bin","rb")
'''for line in file:
    print (line.strip())'''
data=file.read()
print(data)
file.close()
