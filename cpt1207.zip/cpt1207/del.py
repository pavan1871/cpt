import os
os.rename("text.txt")
print("succesfully.........gone to dogs ")